# Oral exam preparation — Around the Globe Quiz

## Five-minute presentation outline

**0:00–0:40 — Problem and goal**
I built an interactive geography quiz. It generates four-option questions from country data and adapts distractor similarity to difficulty.

**0:40–1:20 — Data sources**
The mledoze/countries JSON dataset provides country facts. The World Bank API provides population and GDP per capita. The app downloads and cleans the data with requests and pandas.

**1:20–2:20 — Question generation**
The `generate_question` function chooses a country and topic, finds three distractors, and creates four unique options. Easy uses random distractors, medium uses a shortlist of similar countries, and hard uses the closest candidates. For population and GDP per capita, logarithmic distance compares relative differences.

**2:20–3:00 — Scoring**
Correct answers earn 1, 2, or 3 points for easy, medium, or hard. In mixed mode, each question receives its own difficulty. Wrong answers earn zero. The percentage is earned points divided by maximum possible points, multiplied by 100.

**3:00–4:15 — Demonstration and analysis**
Start a round, answer questions, and show the score, accuracy charts, review table, and CSV export. pandas groups results; NumPy calculates descriptive statistics; matplotlib draws charts.

**4:15–5:00 — Software organization**
The app separates data loading, quiz logic, analysis, and interface code. The README explains setup, requirements are pinned, `.gitignore` excludes generated files, and Git commits document development.

## Questions you should be able to answer

1. **Why use pandas?** To store country records in a DataFrame, clean missing values, merge World Bank indicators, and group player results.
2. **Why use NumPy?** To perform numerical calculations such as weighted scores, means, medians, standard deviations, and logarithmic distance.
3. **Why use matplotlib?** To communicate player performance with bar charts.
4. **What is a distractor?** An incorrect answer option designed to make a multiple-choice question meaningful.
5. **How does difficulty work?** Easy distractors are random; medium distractors come from a shortlist of similar countries; hard distractors are the most similar candidates.
6. **Why logarithmic distance for population?** A difference of 1 million matters differently for a country of 2 million than for a country of 100 million. Log ratios compare relative differences.
7. **How is the score calculated?** Sum the points for correct answers and divide by the total points available, then multiply by 100.
8. **How are missing API values handled?** Data loading uses missing values rather than inventing values; API errors are caught and the app can still use country facts.
9. **What is caching?** Saving downloaded data locally so the app does not need to download the same country file every time it reruns.
10. **What does `@st.cache_data` do?** It caches the result of a data-loading function between Streamlit reruns.
11. **What is a DataFrame?** A two-dimensional labeled data structure with rows and columns, provided by pandas.
12. **Why separate modules?** To keep data access, quiz logic, analysis, and interface independent, easier to test and maintain.

## Before the oral exam

- Run the app from a clean virtual environment.
- Play at least one full round at each difficulty.
- Test each question topic.
- Run `pytest -q`.
- Verify the four options are unique and one answer is correct.
- Explain one example of a hard distractor and the scoring formula.
- Be honest about limitations: the latest World Bank year can differ by country and API data may be missing.
